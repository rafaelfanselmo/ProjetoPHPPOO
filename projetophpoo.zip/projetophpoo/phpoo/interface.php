<?php
echo "Interface - define modelo a ser usado em outras classes";

interface Crud{
	// os metodos da interface devem ser públicos
	public function create($data);
	public function read();
	public function update();
	public function delete();
}

class Noticias implements Crud{

	public function create($data){

	}

	public function read(){
		
	}

	public function update(){
		
	}

	public function delete(){
		
	}
}

