<?php 
echo "Referencia e Clonagem de Ibjetos";
echo "<hr>";
class Pessoa{
	public $idade;

	public function __clone(){
		echo "Clonagem de Objetos <br>";
	}
}

$pessoa = new Pessoa();
$pessoa->idade = 25;

//$pessoa2 é uma referencia do objeto $pessoa
/*
$pessoa2 = $pessoa;
$pessoa2->idade = 35;
echo $pessoa->idade;
*/

//podemos fazer um clone de $pessoa usando a apalavra clone
$pessoa3 = clone $pessoa;
$pessoa3->idade = 35;

echo $pessoa3->idade;


