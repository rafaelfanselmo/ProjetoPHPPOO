<?php 
// Atributo e métodos estático
class Login{
	public static $user;

	public static function verificaLogin(){
		echo "usuário ".self::$user." está logado";
	}

	public function sairSistema(){
		echo "<br> Usuário saiu do sistema";
	}
}

//para atributo e metodo estatico não preciosa nstanciar a classe
Login::$user = "Admin";
Login::verificaLogin();

//porém pode haver metodos public e para acessar é
//necessário instaciar a classe
$login = new Login();
$login->sairSistema(); 
