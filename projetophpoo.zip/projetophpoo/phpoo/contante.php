<?php
//Constante
class Pessoa{
	const nome = "Anselmo";

	public function exibirNome(){
		echo self::nome;
	}
}

class Rafael extends Pessoa{
	const nome = "Rafael";

		public function exibirNome(){
		//parent acessa a constante da classe extendida
		echo parent::nome;
	}
}

/*
$pessoa = new Pessoa();
$pessoa->exibirNome();*/
$rafael = new Rafael();
echo $rafael->exibirNome();