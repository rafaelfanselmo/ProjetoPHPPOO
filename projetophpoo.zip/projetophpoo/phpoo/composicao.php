<?php
echo "Composição <br>";
// Composição: uma classe cria a instância de outra classe dentro de sí própria, sendo assim, quando ela for destruída, a outra classe também será.
echo "<hr>";

class Pessoa{
	public function atribuirNome($nome){
		return "O Nome da pessoa é: ".$nome;
	}
}

class Exibe{
	public $pessoa;
	public $nome;

	function __construct($nome){
		$this->pessoa = new Pessoa();
		$this->nome = $nome;
	}

	public function exibeNome(){
		echo $this->pessoa->atribuirNome($this->nome);
	}
}

$exibe = new Exibe("Rafael Anselmo");
$exibe->exibeNome();
var_dump($exibe);