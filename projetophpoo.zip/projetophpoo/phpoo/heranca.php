<?php 
/*
Herança é um recurso que permite que classes compartilhem
atributos e métodos código ou comportamentos generalizados
*/

/**
 * 
 */
class Veiculo
{
	protected $marca;
	private $cambio;
	public $modelo;
	public $cor;
	public $ano;

	public function Andar(){
		echo "Andou <br>";
	}

	public function Parar(){
		echo "Parou <br>";
	}	

	public function setCambio($c){
		$this->cambio = $c;
	}

	public function getCambio(){
		return $this->cambio;
	}

    private function Acao(){
    	echo "Movimento do Veiculo!! <br>";
    }

	public function MostrarAcao(){
		$this->Acao();
	}


}

class Carro extends Veiculo
{
	public function ligarLimpador()
	{
		echo "Limpando 321 <br>";
	}

	public function setMarca($m){
		$this->marca = $m;
	}

	public function getMarca(){
		return $this->marca;
	}

}

class Moto extends Veiculo
{
	public function descansoDuplo(){
		echo "descanso Abaixado <br>";
	}
}

/*
$veiculo = new Veiculo();
$veiculo->setMarca("Gold <br>");
echo $veiculo->getMarca();
*/
$carro = new Carro();
$carro->setMarca("Gold Carro <br>");
$carro->setCambio("SemiAutmático <br>");
$carro->MostrarAcao();
echo $carro->getMarca();
echo $carro->getCambio();


$carro->modelo = "Gol <br>";
$carro->cor = "Vermelho";
$carro->ano = 2011;
$carro->Andar();
$carro->ligarLimpador();

var_dump($carro);


$moto = new Moto();
$moto->modelo = "Honda";
$moto->cor = "Azul";
$moto->ano = 2015;
$moto->Parar();
$moto->descansoDuplo();
var_dump($moto);