<?php 
echo "Polimorfismo";
echo "<hr>";

class Animal{
	public function Andar(){
		echo "O animal andou <br>";
	}

	public function Correr(){
		echo "O animal Correu <br>";
	}


}

class Cavalo extends Animal{
	/*
	public function Andar(){
		echo "O CAVALO Andou <br>";
	}*/

	public function Andar(){
		$this->Correr();
	}
}

$animal = new Animal();
$animal->Andar();

$cavalo= new Cavalo();
$cavalo->Andar();