<?php
echo "trabalhando vários métodos <hr>";
/*
clone
construct
invoke
tostring
get e set
*/

class Pessoa{
	private $dados = array();


    // eses métodos set get atribui e retorna valor à variável sem precisar chamar os metodos explicitamente.
	/*
	métodos criados para uma variável
	public function __set($nome, $valor){
		$this->nome = $valor;
	}
	public function __get($nome){
		return "O nome é: ".$this->nome;
	}
     */

    public function __set($nome, $valor){
		$this->dados[$nome] = $valor;
	}
	public function __get($nome){
		return "Os dados são: ".$this->dados[$nome];
	}
	public function __tostring(){
		return "Tentei imprimir um objeto";
	}

	public function __invoke(){
		return "Objeto como função";
	}
}

/*
$pessoa = new Pessoa();
$pessoa->nome = "Anselmo" ;
echo $pessoa->nome;
var_dump($pessoa);
*/

$pessoa = new Pessoa();
/*
$pessoa->nome = "Anselmo";
$pessoa->idade = 38;
$pessoa->sexo = "M";
*/
/*
echo $pessoa->nome."<br>";
echo $pessoa->idade."<br>";
echo $pessoa->sexo."<br>";
*/
echo $pessoa();// para chamar o objeto como função
var_dump($pessoa);

