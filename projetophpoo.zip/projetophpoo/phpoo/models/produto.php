<?php 
namespace models;

 class Produto{
 	public function mostrarDetalhes(){
 		echo "Detalhes do Produto da pasta MODELS <br>";
 	}
 }