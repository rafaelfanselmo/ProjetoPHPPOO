<?php
require 'classes/produto.php';
require 'models/produto.php';

// meio de chamar as classes de mesmo nome mas de diferentes pastas
use classes\Produto as productModel;
use models\Produto as productClasses;

$produto = new productModel();
$produto->mostrarDetalhes();

$produto2 = new productClasses();
$produto2->mostrarDetalhes();