<?php 

namespace classes;

 class Produto{
 	public function mostrarDetalhes(){
 		echo "Detalhes do Produto da pasta CLASSES <br>";
 	}
 }