<?php 
//echo "primeiro OO";
/**
 * 
 */			
class Login 
{
	private $email;
	private $senha;
	private $nome;

	public function __construct($email, $senha, $nome){
		$this->nome = $nome;
		$this->setEmail($email);
		$this->setSenha($senha);
	}

    public function getNome(){
		return $this->nome;
	}

	public function setNome($n){
		$this->nome = $n;
	}

	public function getEmail(){
		return $this->email;
	}

	public function setEmail($e){
		$email = filter_var($e, FILTER_SANITIZE_EMAIL);
		$this->email = $email;
	}

	public function getSenha(){
		return $this->senha;
	}

	public function setSenha($s){
		$this->senha = $s;
	}
	
	public function Logar()
	{
		if ($this->email == "teste@teste.com" and $this->senha=="123456") {	
			echo "Logado";
		}else{
			echo "não logado";
		}
	}
}

$logar = new Login("teste@teste.com","123456","Rafael Anselmo");
$logar->Logar();
echo "<br>";
echo $logar->getEmail();
echo "<br>";
echo $logar->getSenha();
echo "<br>";
echo $logar->getNome();




/* Primeira classe
class Pessoa
{
	public $nome;
	public $idade;

	public function Falar(){
		echo $this->nome." de ".$this->idade." idade ";
	}
}

$pessoa = new Pessoa();
$pessoa->nome = "Rafael F. Anselmo";
$pessoa->idade = 38;
$pessoa->Falar();
//echo $pessoa->nome; 
//echo $pessoa->idade;

var_dump($pessoa);
*/