<?php 

require_once 'vendor/autoload.php';

$produto = new \App\Model\Produto();
/*$produto->setId(3);
$produto->setNome("Cadeira");
$produto->setDescricao("Gamer");
*/
$produtoDao = new \App\Model\ProdutoDao();
//$produtoDao->create($produto);
$produtoDao->delete(2);

$produtoDao->read();

foreach ($produtoDao->read() as $produto) {
	echo $produto['nome']."<br>".$produto['descricao']."<hr>";
}

//var_dump($produto);

/*
require_once 'vendor/autoload.php';

Exemplo de uso do composer com libs baixadas no portal https://packagist.org/
use Cocur\Slugify\Slugify;
$slugify = new Slugify();
echo $slugify->slugify('Hello Worldààà âã!'); // hello-world
echo $slugify->slugify('Hello World!', '_');
$slugify->addRule('i', 'ey');
echo $slugify->slugify('Hi'); // hey
*/